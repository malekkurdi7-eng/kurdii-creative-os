import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme';
import { Button, Card } from '../ui';
import { DIFFERENCES, PACKAGES } from '../data';

export default function HomeScreen() {
  const nav = useNavigation<any>();
  return (
    <ScrollView style={s.root} contentContainerStyle={{ paddingBottom: 40 }}>
      <View style={s.hero}>
        <Text style={s.brand}>DREAM WAY</Text>
        <Text style={s.sub}>DESTINATION MANAGEMENT COMPANY • JORDAN</Text>
        <Text style={s.title}>Your local partner for Jordan, the Holy Land & Egypt</Text>
        <Text style={s.tag}>Make your Dream Our Way</Text>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 20 }}>
          <Button label="Browse Packages" onPress={() => nav.navigate('Packages')} style={{ flex: 1 }} />
          <Button label="Request Quote" variant="outline" onPress={() => nav.navigate('Quote')} style={{ flex: 1 }} />
        </View>
      </View>

      <Text style={s.h2}>The Dream Way Difference</Text>
      <View style={s.grid}>
        {DIFFERENCES.map((d) => (
          <Card key={d.title} style={s.gridItem}>
            <Ionicons name={d.icon} size={26} color={colors.gold} />
            <Text style={s.cardTitle}>{d.title}</Text>
            <Text style={s.cardText}>{d.text}</Text>
          </Card>
        ))}
      </View>

      <Text style={s.h2}>Featured</Text>
      {PACKAGES.slice(0, 3).map((p) => (
        <Card key={p.id} style={{ marginHorizontal: 20, marginBottom: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Ionicons name={p.icon} size={28} color={colors.teal} />
            <View style={{ flex: 1 }}>
              <Text style={s.cardTitle}>{p.title}</Text>
              <Text style={s.cardText}>{p.tagline}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.muted} onPress={() => nav.navigate('PackageDetail', { id: p.id })} />
          </View>
        </Card>
      ))}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.navy },
  hero: { padding: 24, paddingTop: 60, backgroundColor: colors.navyLight, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 },
  brand: { color: colors.gold, fontSize: 34, fontWeight: '800', letterSpacing: 4 },
  sub: { color: colors.muted, fontSize: 10, letterSpacing: 2, marginTop: 4 },
  title: { color: colors.white, fontSize: 22, fontWeight: '700', marginTop: 24, lineHeight: 30 },
  tag: { color: colors.teal, fontSize: 14, marginTop: 8, fontStyle: 'italic' },
  h2: { color: colors.white, fontSize: 18, fontWeight: '700', margin: 20, marginBottom: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 14 },
  gridItem: { width: '46%', margin: '2%', gap: 6 },
  cardTitle: { color: colors.white, fontWeight: '700', fontSize: 15 },
  cardText: { color: colors.muted, fontSize: 13, lineHeight: 18 },
});
