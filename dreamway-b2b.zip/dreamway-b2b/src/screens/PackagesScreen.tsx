import React, { useState } from 'react';
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme';
import { Card } from '../ui';
import { CATEGORIES, Category, PACKAGES } from '../data';

export default function PackagesScreen() {
  const nav = useNavigation<any>();
  const [cat, setCat] = useState<Category | 'All'>('All');
  const list = cat === 'All' ? PACKAGES : PACKAGES.filter((p) => p.category === cat);
  return (
    <View style={s.root}>
      <Text style={s.title}>Packages & Services</Text>
      <View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}>
          {(['All', ...CATEGORIES] as const).map((c) => (
            <Pressable key={c} onPress={() => setCat(c)} style={[s.chip, cat === c && s.chipOn]}>
              <Text style={[s.chipText, cat === c && { color: colors.navy }]}>{c}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>
      <FlatList
        data={list}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        renderItem={({ item }) => (
          <Pressable onPress={() => nav.navigate('PackageDetail', { id: item.id })}>
            <Card>
              <View style={{ flexDirection: 'row', gap: 14, alignItems: 'center' }}>
                <Ionicons name={item.icon} size={30} color={colors.gold} />
                <View style={{ flex: 1 }}>
                  <Text style={s.cat}>{item.category.toUpperCase()}</Text>
                  <Text style={s.name}>{item.title}</Text>
                  <Text style={s.tag}>{item.tagline}</Text>
                </View>
              </View>
            </Card>
          </Pressable>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.navy, paddingTop: 60 },
  title: { color: colors.white, fontSize: 24, fontWeight: '800', marginHorizontal: 20, marginBottom: 14 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  chipOn: { backgroundColor: colors.gold, borderColor: colors.gold },
  chipText: { color: colors.text, fontSize: 13, fontWeight: '600' },
  cat: { color: colors.teal, fontSize: 10, letterSpacing: 1.5, fontWeight: '700' },
  name: { color: colors.white, fontSize: 16, fontWeight: '700', marginTop: 2 },
  tag: { color: colors.muted, fontSize: 13, marginTop: 2 },
});
