import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, CONTACT } from '../theme';
import { Button, Card, open } from '../ui';

export default function ContactScreen() {
  return (
    <ScrollView style={s.root} contentContainerStyle={{ padding: 20, paddingTop: 60 }}>
      <Text style={s.title}>About & Contact</Text>
      <Card style={{ marginTop: 16 }}>
        <Text style={s.h}>Who we are</Text>
        <Text style={s.p}>
          A locally owned, boutique Destination Management Company with a global heart. Our mission: to be the most trusted, innovative and soulful gateway to the Middle East, unveiling the soul of the region, bridging civilizations and protecting our heritage.
        </Text>
      </Card>
      <Card style={{ marginTop: 14 }}>
        <Text style={s.h}>Travel with a conscience</Text>
        <Text style={s.p}>We partner with the Iraq Al-Amir Women’s Cooperative and promote eco-lodges and Leave No Trace camping in Wadi Rum.</Text>
      </Card>
      <Card style={{ marginTop: 14, gap: 12 }}>
        <Row icon="call" text={CONTACT.phoneDisplay} onPress={() => open(`tel:${CONTACT.phone}`)} />
        <Row icon="mail" text={CONTACT.email} onPress={() => open(`mailto:${CONTACT.email}`)} />
        <Row icon="location" text={CONTACT.address} />
      </Card>
      <Button label="Chat on WhatsApp" onPress={() => open(`https://wa.me/${CONTACT.phone.replace('+', '')}`)} style={{ marginTop: 18 }} />
    </ScrollView>
  );
}

function Row({ icon, text, onPress }: { icon: any; text: string; onPress?: () => void }) {
  return (
    <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
      <Ionicons name={icon} size={20} color={colors.gold} />
      <Text style={[s.p, { flex: 1, marginTop: 0, color: onPress ? colors.teal : colors.text }]} onPress={onPress}>{text}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.navy },
  title: { color: colors.white, fontSize: 24, fontWeight: '800' },
  h: { color: colors.white, fontWeight: '700', fontSize: 16 },
  p: { color: colors.text, fontSize: 14, lineHeight: 21, marginTop: 8 },
});
