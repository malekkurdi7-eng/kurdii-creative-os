import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { colors } from '../theme';
import { Button, Card } from '../ui';
import { PACKAGES } from '../data';

function Section({ title, items, icon }: { title: string; items: string[]; icon: any }) {
  return (
    <Card style={{ marginTop: 14 }}>
      <Text style={s.h}>{title}</Text>
      {items.map((i) => (
        <View key={i} style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
          <Ionicons name={icon} size={16} color={colors.gold} style={{ marginTop: 2 }} />
          <Text style={s.item}>{i}</Text>
        </View>
      ))}
    </Card>
  );
}

export default function PackageDetailScreen() {
  const { id } = useRoute<any>().params;
  const nav = useNavigation<any>();
  const p = PACKAGES.find((x) => x.id === id)!;
  return (
    <ScrollView style={s.root} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
      <Ionicons name={p.icon} size={44} color={colors.gold} />
      <Text style={s.cat}>{p.category.toUpperCase()}</Text>
      <Text style={s.title}>{p.title}</Text>
      <Text style={s.tag}>{p.tagline}</Text>
      <Text style={s.desc}>{p.description}</Text>
      <Section title="Highlights" items={p.highlights} icon="location" />
      <Section title="What agents love" items={p.perks} icon="checkmark-circle" />
      <Button label="Request a Quote for this" onPress={() => nav.navigate('Tabs', { screen: 'Quote', params: { interest: p.title } })} style={{ marginTop: 22 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.navy },
  cat: { color: colors.teal, fontSize: 11, letterSpacing: 2, fontWeight: '700', marginTop: 12 },
  title: { color: colors.white, fontSize: 26, fontWeight: '800', marginTop: 4 },
  tag: { color: colors.gold, fontSize: 14, marginTop: 6, fontStyle: 'italic' },
  desc: { color: colors.text, fontSize: 15, lineHeight: 22, marginTop: 14 },
  h: { color: colors.white, fontWeight: '700', fontSize: 16 },
  item: { color: colors.text, fontSize: 14, flex: 1, lineHeight: 20 },
});
