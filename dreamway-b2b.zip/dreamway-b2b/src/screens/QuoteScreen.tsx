import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { colors, CONTACT } from '../theme';
import { Button, open } from '../ui';

const empty = { agency: '', name: '', email: '', phone: '', pax: '', dates: '', interest: '', notes: '' };

function Field({ label, value, onChange, ...rest }: any) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={s.label}>{label}</Text>
      <TextInput value={value} onChangeText={onChange} placeholderTextColor={colors.muted} style={[s.input, rest.multiline && { height: 90, textAlignVertical: 'top' }]} {...rest} />
    </View>
  );
}

export default function QuoteScreen() {
  const route = useRoute<any>();
  const [f, setF] = useState(empty);
  const set = (k: keyof typeof empty) => (v: string) => setF((p) => ({ ...p, [k]: v }));

  useEffect(() => {
    if (route.params?.interest) set('interest')(route.params.interest);
  }, [route.params?.interest]);

  const message = () =>
    [
      'Quote request via Dream Way B2B app',
      `Agency: ${f.agency}`,
      `Contact: ${f.name} | ${f.email} | ${f.phone}`,
      `Travelers: ${f.pax}`,
      `Travel dates: ${f.dates}`,
      `Interested in: ${f.interest}`,
      `Notes: ${f.notes}`,
    ].join('\n');

  const valid = () => {
    if (!f.agency.trim() || !f.name.trim() || !f.email.includes('@')) {
      Alert.alert('Missing info', 'Please fill in agency, your name and a valid email.');
      return false;
    }
    return true;
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={s.root} contentContainerStyle={{ padding: 20, paddingTop: 60, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Text style={s.title}>Request a Quote</Text>
        <Text style={s.sub}>Send your request straight to our reservations team.</Text>
        <Field label="Agency name *" value={f.agency} onChange={set('agency')} placeholder="e.g. Sunrise Travel" />
        <Field label="Your name *" value={f.name} onChange={set('name')} />
        <Field label="Email *" value={f.email} onChange={set('email')} keyboardType="email-address" autoCapitalize="none" />
        <Field label="Phone / WhatsApp" value={f.phone} onChange={set('phone')} keyboardType="phone-pad" />
        <Field label="Number of travelers" value={f.pax} onChange={set('pax')} keyboardType="number-pad" />
        <Field label="Travel dates" value={f.dates} onChange={set('dates')} placeholder="e.g. 10–18 March 2027" />
        <Field label="Interested in" value={f.interest} onChange={set('interest')} placeholder="Package or service" />
        <Field label="Notes" value={f.notes} onChange={set('notes')} multiline />
        <Button label="Send by Email" onPress={() => valid() && open(`mailto:${CONTACT.email}?subject=${encodeURIComponent('Quote request: ' + f.agency)}&body=${encodeURIComponent(message())}`)} />
        <Button label="Send by WhatsApp" variant="outline" style={{ marginTop: 10 }} onPress={() => valid() && open(`https://wa.me/${CONTACT.phone.replace('+', '')}?text=${encodeURIComponent(message())}`)} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.navy },
  title: { color: colors.white, fontSize: 24, fontWeight: '800' },
  sub: { color: colors.muted, marginTop: 4, marginBottom: 20 },
  label: { color: colors.text, fontSize: 13, marginBottom: 6, fontWeight: '600' },
  input: { backgroundColor: colors.navyLight, borderWidth: 1, borderColor: colors.border, color: colors.white, borderRadius: 10, padding: 12, fontSize: 15 },
});
