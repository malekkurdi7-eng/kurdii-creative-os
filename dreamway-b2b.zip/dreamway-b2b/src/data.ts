import { Ionicons } from '@expo/vector-icons';
import type { ComponentProps } from 'react';

export type IconName = ComponentProps<typeof Ionicons>['name'];
export type Category = 'Jordan' | 'Holy Land' | 'Egypt' | 'Pilgrimage' | 'Adventure' | 'MICE & Weddings';

export interface Package {
  id: string;
  title: string;
  category: Category;
  tagline: string;
  icon: IconName;
  description: string;
  highlights: string[];
  perks: string[];
}

export const CATEGORIES: Category[] = ['Jordan', 'Holy Land', 'Egypt', 'Pilgrimage', 'Adventure', 'MICE & Weddings'];

export const PACKAGES: Package[] = [
  {
    id: 'guaranteed',
    title: 'Guaranteed Departures',
    category: 'Jordan',
    tagline: '100% guaranteed to depart, no minimums',
    icon: 'shield-checkmark',
    description:
      'Scheduled tours that run whether you book one traveler or ten. Premium touches included even on a group tour.',
    highlights: ['Petra', 'Dead Sea', 'Wadi Rum', 'Jerash'],
    perks: ['No minimums', 'Lunch with a local family', 'Visits to authentic villages', 'Free collective visa for stays of 48+ hours'],
  },
  {
    id: 'jordan-classics',
    title: 'Jordan Classics & Hidden Gems',
    category: 'Jordan',
    tagline: 'The Kingdom of Contrasts',
    icon: 'compass',
    description:
      'The icons plus the Dream Way touch: local life and untouched nature beyond the guidebook.',
    highlights: ['Rose-red city of Petra', 'Dead Sea', 'Wadi Rum', 'Iraq Al-Amir Women’s Cooperative', 'Dana Biosphere Reserve'],
    perks: ['Bedouin hospitality & mint tea', 'Grandmother’s Kitchen', 'Nai (reed flute) workshop', 'Zarb underground feast'],
  },
  {
    id: 'holy-land',
    title: 'Jordan & Holy Land Combined',
    category: 'Holy Land',
    tagline: 'The Cradle of Faith',
    icon: 'navigate',
    description:
      'Cross-border itineraries linking Mount Nebo to the holy sites across the river, with all logistics handled.',
    highlights: ['Via Dolorosa, Jerusalem', 'Church of the Nativity, Bethlehem', 'Jericho', 'Mount Nebo'],
    perks: ['Private cross-border transfers', 'Visa paperwork handled', 'Departure taxes managed', 'Theology-trained guides'],
  },
  {
    id: 'egypt',
    title: 'Egypt: Where History Began',
    category: 'Egypt',
    tagline: 'Pharaohs & Pyramids',
    icon: 'triangle',
    description: 'Pyramids, Nile and Red Sea, combinable with Jordan and the Holy Land in one seamless trip.',
    highlights: ['Pyramids of Giza & the Sphinx', 'Valley of the Kings', 'Luxury Nile cruise', 'Sharm El-Sheikh reefs'],
    perks: ['Multi-country combinations', 'Border crossing expertise', '24/7 support'],
  },
  {
    id: 'sacred-pathways',
    title: 'Sacred Pathways',
    category: 'Pilgrimage',
    tagline: 'Footsteps of Moses • The Holy Family',
    icon: 'sparkles',
    description:
      'Specialized pilgrimage itineraries with guides who are experts in theology and biblical history.',
    highlights: ['Footsteps of Moses', 'The Holy Family route', 'Mount Nebo', 'Jordan–Holy Land–Egypt links'],
    perks: ['Expert theological guides', 'Smooth border logistics', 'Group-friendly planning'],
  },
  {
    id: 'adventure',
    title: 'Adventure & Sports',
    category: 'Adventure',
    tagline: 'High-octane and wild nature',
    icon: 'bicycle',
    description: 'From desert buggies to canyoning, safe, fast and exhilarating.',
    highlights: ['Can-Am Maverick Sport 1000cc buggies (Aqaba & Wadi Rum)', 'Canyoning in Wadi Mujib', 'Red Sea snorkeling', 'Jordan Trail hiking'],
    perks: ['Safety-first operations', 'Leave No Trace camping in Wadi Rum'],
  },
  {
    id: 'mice',
    title: 'MICE & Incentives',
    category: 'MICE & Weddings',
    tagline: 'From boardrooms to desert ballrooms',
    icon: 'briefcase',
    description: 'Team-building and corporate events with a sense of place.',
    highlights: ['Treasure hunts in Petra', 'Gala dinners under the stars in Little Petra'],
    perks: ['Full event management', 'Custom programs'],
  },
  {
    id: 'weddings',
    title: 'Weddings in Jordan',
    category: 'MICE & Weddings',
    tagline: 'A fairy-tale “I Do” in the heart of history',
    icon: 'heart',
    description: 'Everything from legal paperwork to floral arrangements.',
    highlights: ['Legal paperwork handled', 'Floral & venue arrangements'],
    perks: ['End-to-end planning'],
  },
];

export const DIFFERENCES: { icon: IconName; title: string; text: string }[] = [
  { icon: 'shield-checkmark', title: 'Guaranteed departures', text: 'Scheduled tours always run, no minimums.' },
  { icon: 'receipt', title: 'Transparent pricing', text: 'No hidden fees, honest competitive value.' },
  { icon: 'headset', title: '24/7 support', text: 'Round-the-clock team for you and your clients.' },
  { icon: 'swap-horizontal', title: 'Border expertise', text: 'Jordan, Israel and Egypt crossings handled like a VIP.' },
];
