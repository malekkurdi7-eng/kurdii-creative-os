export const colors = {
  navy: '#0B1829',
  navyLight: '#14283F',
  gold: '#C9A357',
  teal: '#2A8FAB',
  white: '#FFFFFF',
  text: '#E8EDF3',
  muted: '#8FA1B5',
  border: '#22364D',
};
export const CONTACT = {
  email: 'info@dreamway-dmc.com',
  phone: '+962791038065',
  phoneDisplay: '+962 791 038 065',
  address: 'King Abdullah II Street, Amman, Jordan',
};
