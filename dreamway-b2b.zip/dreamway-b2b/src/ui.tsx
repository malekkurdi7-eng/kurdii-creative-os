import React from 'react';
import { Linking, Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { colors } from './theme';

export function Button({ label, onPress, variant = 'gold', style }: { label: string; onPress: () => void; variant?: 'gold' | 'outline'; style?: ViewStyle }) {
  const gold = variant === 'gold';
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [s.btn, gold ? s.btnGold : s.btnOutline, pressed && { opacity: 0.8 }, style]}
    >
      <Text style={[s.btnText, { color: gold ? colors.navy : colors.gold }]}>{label}</Text>
    </Pressable>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[s.card, style]}>{children}</View>;
}

export const open = (url: string) => Linking.openURL(url).catch(() => {});

const s = StyleSheet.create({
  btn: { paddingVertical: 14, paddingHorizontal: 20, borderRadius: 12, alignItems: 'center' },
  btnGold: { backgroundColor: colors.gold },
  btnOutline: { borderWidth: 1.5, borderColor: colors.gold },
  btnText: { fontWeight: '700', fontSize: 15, letterSpacing: 0.3 },
  card: { backgroundColor: colors.navyLight, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: colors.border },
});
